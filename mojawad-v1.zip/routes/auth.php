<?php
use App\Http\Controllers\Auth\{AuthenticatedSessionController,RegisteredUserController};
use Illuminate\Support\Facades\Route;
Route::middleware('guest')->group(function(){
    Route::get('/login',    [AuthenticatedSessionController::class,'create'])->name('login');
    Route::post('/login',   [AuthenticatedSessionController::class,'store']);
    Route::get('/register', [RegisteredUserController::class,'create'])->name('register');
    Route::post('/register',[RegisteredUserController::class,'store']);
});
Route::middleware('auth')->post('/logout',[AuthenticatedSessionController::class,'destroy'])->name('logout');
