<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('qaris', function (Blueprint $t) {
            $t->id();
            $t->string('name');
            $t->string('slug')->unique();
            $t->string('image')->nullable();
            $t->longText('biography')->nullable();
            $t->foreignId('created_by')->constrained('users')->onDelete('cascade');
            $t->boolean('is_featured')->default(false);
            $t->enum('status', ['active', 'inactive', 'pending'])->default('pending');
            $t->timestamps();
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('qaris');
    }
};
